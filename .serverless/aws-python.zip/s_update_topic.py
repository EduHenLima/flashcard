import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='eduardolima',
    application_name='aws-python',
    app_uid='rJLvSqJJ1dbtgBPc1K',
    org_uid='2763e3ef-f172-4ee5-8198-690f45460aa4',
    deployment_uid='7cfe55a2-cb75-465e-af6e-d1d28eefaa98',
    service_name='aws-python',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='6.2.3',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'aws-python-dev-update_topic', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('src/API/topic/updateTopic.update')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
